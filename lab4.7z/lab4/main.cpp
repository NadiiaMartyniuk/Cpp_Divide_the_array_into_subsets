#include <iostream>
#include<string>
#include<fstream>
#include <sstream>
#include<math.h>

using namespace std;

/*
Zadanie 4.1. Wczytanie danych

Nale¿y stworzyæ odpowiedni¹ funkcjê umo¿liwiaj¹ca wczytanie danych do programu
z pliku.
Schemat wykonania zadania jest nastêpuj¹cy:
• wczytanie rozmiaru tablicy z pliku,
• przydzielenie pamiêci,
• wype³nienie tablicy danymi z pliku.*/

struct student{
    string imie;
    string nazwisko;
    string punkty;
};
void zadanie4_1(int *liczba_studentow, student*&tab);
void zadanie4_2(int *liczba_studentow, student*tab);
void Wyswietl(int i, int n, student*tab);
void usunTabliceStudentow(student *&tab);
int Podzial_na_dwa_zbiora(int n, student *&tab);
void zadanie4_3(int liczba_studentow, student*tab);
void podzial_na_trzy_podzbiora(int liczba_studentow, student*&tab, int *indeks2, int *indeks3);

void zadanie4_1(int *liczba_studentow, student*&tab){
    usunTabliceStudentow(tab);
    int liczba_s;
    string linia;
    ifstream plik;
    char srednik;
    plik.open("studenci.csv");
    plik>>liczba_s;
    *liczba_studentow=liczba_s;
    tab = new student[liczba_s];
    for (int i=0; i<2; i++){
        plik>>srednik;
    }
    for (int i=0; i<liczba_s; i++){
        plik>>linia;
        istringstream ss(linia);
        getline(ss, tab[i].imie, ';');
        getline(ss, tab[i].nazwisko, ';');
        getline(ss, tab[i].punkty);
    }
    plik.close();
    cout<<"Dane zostaly wczytane "<<endl;

}

/*Zadanie 4.2.
Podzia³ zbioru na dwie czêœci
Nale¿y stworzyæ funkcjê, która w oparciu o wczytane z pliku dane o studentach podzieli
tablicê w taki sposób, aby
• w pierwszej czêœci znaleŸli siê studenci, którzy otrzymali mniej ni¿ 10 b¹dŸ 10
punktów
• w drugiej studenci, którzy otrzymali wiêcej ni¿ 10 punktów.*/


void zadanie4_2(int liczba_studentow, student*tab){
    cout<<"TABLICA PRZED SORTOWANIEM"<<endl;
    int i;
    i=0;
    Wyswietl(i,liczba_studentow, tab);
    int indeks;
    indeks=Podzial_na_dwa_zbiora(liczba_studentow, tab);
    cout<<endl;
    cout<<"Studenci, ktorzy otrzymali <=10 punktow:"<<endl;
    Wyswietl(i,indeks, tab);
    cout<<"Studenci, ktorzy otrzymali >10 punktow:"<<endl;
    Wyswietl(indeks, liczba_studentow, tab);

}

int Podzial_na_dwa_zbiora(int n, student *&tab){
    int i=0;
    int j=n-1;
    while(i<j){
        while (((atoi(tab[i].punkty.c_str()))<=10)&&(i<j)){i++;}
        while (((atoi(tab[j].punkty.c_str()))>10)&&(i<j)){j--;}
        if (i<j){
            swap(tab[i].punkty, tab[j].punkty);
            i++;
            j--;
        }
    }
    if (atoi(tab[i].punkty.c_str())<=10)
        return i+1;
    return i;
}

void podzial_na_trzy_podzbiora(int liczba_studentow, student*&tab, int *indeks2, int *indeks3){
    int i,j,k;
    i=-1;
    j=0;
    k=liczba_studentow;
    while (j<k){
        if (((atoi(tab[j].punkty.c_str()))%3==0)){
                i++;
                swap(tab[i],tab[j]);
                j++;
        }
    else{
        if (((atoi(tab[j].punkty.c_str()))%3==1)){
            k--;
            swap(tab[k],tab[j]);
            }
        else {
            j++;
        }
    }
    }
    *indeks2=i;
    *indeks3=k;
}

void zadanie4_3(int liczba_studentow, student*tab){
    int i,indeks2, indeks3;
    i=0;
    podzial_na_trzy_podzbiora(liczba_studentow, tab, &indeks2, &indeks3);
    cout<<endl<<"Studenci, ktorzy otrzymali liczbe punktow podzielnych przez 3"<<endl;
    Wyswietl(i,indeks2+1, tab);
    cout<<"Studenci, ktorzy otrzymali liczbe punktow podzielnych przez 3 z reszta 1"<<endl;
    Wyswietl(indeks3, liczba_studentow, tab);
    cout<<"Studenci, ktorzy otrzymali liczbe punktow podzielnych przez 3 z reszta 2"<<endl;
    Wyswietl(indeks2+1, indeks3, tab);
}

void Wyswietl(int i, int n, student*tab){
    while(i<n){
        cout<<i+1<<". "<<tab[i].imie<<" "<<tab[i].nazwisko<<" "<<tab[i].punkty<<endl;
        i++;
    }
}
void usunTabliceStudentow(student *&tab){
    delete []tab;
}
int main()
{
    int liczba_studentow, zadanie, k;
    student* tab = nullptr;
    cout<<"1 - zadanie 4.1"<<endl;
    cout<<"2 - zadanie 4.2"<<endl;
    cout<<"3 - zadanie 4.3"<<endl;
    k=0;
    while (k==0){
    cout<<"Jakie zadanie chcesz wykonac ?"<<endl;
    cin>>zadanie;
    switch (zadanie){
        case 1:
            zadanie4_1(&liczba_studentow, tab);
            break;
        case 2:
            zadanie4_2(liczba_studentow, tab);
            break;
        case 3:
            zadanie4_3(liczba_studentow, tab);
            break;
        default:
            cout<<"Nie ma takiego zadania "<<endl;
            k=1;
    }}
    usunTabliceStudentow(tab);
    return 0;
}
